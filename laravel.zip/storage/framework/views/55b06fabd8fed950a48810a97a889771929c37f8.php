

<div class="form-group">
<label for="cod_compra"  class="control-label"><?php echo e('cod_compra'); ?></label>
<input type="text" class="form-control <?php echo e($errors->has('cod_compra')?'is-invalid':''); ?>" name="cod_compra" id="cod_compra" value="<?php echo e(isset($compra->cod_compra)?$compra->cod_compra:old('cod_compra')); ?>">
<?php echo $errors->first('cod_compra','<div class="invalid-feedback">:message</div>'); ?>

</div>

<div class="form-group" class="control-label">
<label for="producto"><?php echo e('producto'); ?></label>
<input type="text" class="form-control <?php echo e($errors->has('producto')?'is-invalid':''); ?>" name="producto" id="producto" value="<?php echo e(isset($compra->producto)?$compra->producto:old('producto')); ?>">
<?php echo $errors->first('producto','<div class="invalid-feedback">:message</div>'); ?>

</div>

<div class="form-group" class="control-label"> 
<label for="cantidad"><?php echo e('cantidad'); ?></label>
<input type="text" class="form-control <?php echo e($errors->has('cantidad')?'is-invalid':''); ?>" name="cantidad" id="cantidad" value="<?php echo e(isset($compra->cantidad)?$compra->cantidad:old('cantidad')); ?>">
<?php echo $errors->first('cantidad','<div class="invalid-feedback">:message</div>'); ?>

</div>

<input type="submit" class="btn btn-success" value="<?php echo e($Modo=='crear'? 'Agregar ':'Modificar'); ?>">
<a class="btn btn-primary" href="<?php echo e(url('compras')); ?>" >Regresar</a>
<?php /**PATH C:\xampp\htdocs\Laravel-Apps\Inventario\resources\views/compras/form.blade.php ENDPATH**/ ?>