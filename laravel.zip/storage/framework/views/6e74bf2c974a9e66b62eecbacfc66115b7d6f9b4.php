

<form action="<?php echo e(url('/compras')); ?>" method="post">
<?php echo e(csrf_field()); ?>




</form>

<?php $__env->startSection('content'); ?>


<div class="container">
 


<form action="<?php echo e(url('/compras')); ?>" class="form-horizontal" method="post">

<?php echo e(csrf_field()); ?>


<?php echo $__env->make('compras.form',['Modo'=>'crear'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


</form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel-Apps\Inventario\resources\views/compras/create.blade.php ENDPATH**/ ?>