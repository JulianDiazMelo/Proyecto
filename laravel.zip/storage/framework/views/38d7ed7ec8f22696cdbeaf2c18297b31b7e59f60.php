
<?php $__env->startSection('content'); ?>

<div class='container'>


<?php if(Session::has('Mensaje')): ?>
<div class="alert alert-success" role="alert">
<?php echo e(Session::get('Mensaje')); ?>

</div>

<?php endif; ?>




<a href="<?php echo e(url('productos/create')); ?>" class= "btn btn-success" >Agregar Producto</a>
<br/>
<br/>

<table class="table table-light table-hover">
    <thead class="thead-light">
        <tr>
            <th>ID</th>
            <th>Producto</th>
            <th>Cantidad</th>
            <th>Tamaño</th>
            <th>Precio Individual</th>
            <th>Fecha Vencimiento</th>
            <th>Acciones</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
        <td><?php echo e($loop->iteration); ?></td>
        <td><?php echo e($producto->producto); ?></td>
        <td><?php echo e($producto->cantidad); ?></td>
        <td><?php echo e($producto->tamano); ?></td>
        <td><?php echo e($producto->precio_individual); ?></td>
        <td><?php echo e($producto->fecha_vencimiento); ?></td>
        <td>
        <a class="btn btn-warning" href="<?php echo e(url('/productos/'.$producto->id.'/edit')); ?>">
        Editar
        </a>    
        <form method="post" action="<?php echo e(url('/productos/'.$producto->id)); ?>" style="display:inline">
        <?php echo e(csrf_field()); ?>

        <?php echo e(method_field('DELETE')); ?>

        <button class="btn btn-danger" type="submit" onclick="return confirm('¿BORRAR?')">Borrar</button>
        
        </form>
        </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
    </tbody>
</table>
<?php echo e($productos->links()); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel-Apps\Inventario\resources\views/productos/index.blade.php ENDPATH**/ ?>