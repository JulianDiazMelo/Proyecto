

<div class="form-group">
<label for="documento" class="control-label"><?php echo e('Documento'); ?></label>
<input type="text" class="form-control <?php echo e($errors->has('documento')?'is-invalid':''); ?>" name="documento" id="documento" value="<?php echo e(isset($cliente->documento)?$cliente->documento:old('documento')); ?>">
<?php echo $errors->first('documento','<div class="invalid-feedback">:message</div>'); ?>

</div>

<div class="form-group">
<label for="nombre" class="control-label"><?php echo e('Nombre'); ?></label>
<input type="text"  class="form-control <?php echo e($errors->has('nombre')?'is-invalid':''); ?>" name="nombre" id="nombre" value="<?php echo e(isset($cliente->nombre)?$cliente->nombre:old('nombre')); ?>">
<?php echo $errors->first('nombre','<div class="invalid-feedback">:message</div>'); ?>

</div>

<div class="form-group">
<label for="apellido" class="control-label"><?php echo e('Apellido'); ?></label>
<input type="text" class="form-control <?php echo e($errors->has('apellido')?'is-invalid':''); ?>" name="apellido" id="apellido" value="<?php echo e(isset($cliente->apellido)?$cliente->apellido:old('apellido')); ?>">
<?php echo $errors->first('apellido','<div class="invalid-feedback">:message</div>'); ?>

</div>

<div class="form-group">
<label for="id_compra" class="control-label"><?php echo e('ID Compra'); ?></label>
<input type="text" class="form-control <?php echo e($errors->has('id_compra')?'is-invalid':''); ?>" name="id_compra" id="id_compra" value="<?php echo e(isset($cliente->id_compra)?$cliente->id_compra:old('id_compra')); ?>">
<?php echo $errors->first('id_compra','<div class="invalid-feedback">:message</div>'); ?>

</div>

<input type="submit" class="btn btn-success" value="<?php echo e($Modo=='crear'? 'Agregar ':'Modificar'); ?>">
<a class="btn btn-primary" href="<?php echo e(url('compras')); ?>" >Regresar</a>
<?php /**PATH C:\xampp\htdocs\Laravel-Apps\Inventario\resources\views/clientes/form.blade.php ENDPATH**/ ?>