

<div class="form-group">
<label for="producto" class="control-label"><?php echo e('Producto'); ?></label>
<input type="text" class="form-control <?php echo e($errors->has('producto')?'is-invalid':''); ?> " name="producto" id="producto" value="<?php echo e(isset($producto->producto)?$producto->producto:old('producto')); ?>">
<?php echo $errors->first('producto','<div class="invalid-feedback">:message</div>'); ?>



</div>
<div class="form-group">
<label for="cantidad" class="control-label"><?php echo e('Cantidad'); ?></label>
<input type="text" class="form-control <?php echo e($errors->has('cantidad')?'is-invalid':''); ?> " name="cantidad" id="cantidad" value="<?php echo e(isset($producto->cantidad)?$producto->cantidad:old('cantidad')); ?>">
<?php echo $errors->first('cantidad','<div class="invalid-feedback">:message</div>'); ?>

</div>
<div class="form-group">
<label for="tamano" class="control-label"><?php echo e('Tamaño'); ?></label>
<input type="text" class="form-control <?php echo e($errors->has('tamano')?'is-invalid':''); ?> " name="tamano" id="tamano" value="<?php echo e(isset($producto->tamano)?$producto->tamano:old('tamano')); ?>">
<?php echo $errors->first('tamano','<div class="invalid-feedback">:message</div>'); ?>

</div>
<div class="form-group">
<label for="precio_individual" class="control-label"><?php echo e('Precio Individual'); ?></label>
<input type="text" class="form-control <?php echo e($errors->has('precio_individual')?'is-invalid':''); ?> " name="precio_individual" id="precio_individual" value="<?php echo e(isset($producto->precio_individual)?$producto->precio_individual:old('precio_individual')); ?>">
<?php echo $errors->first('precio_individual','<div class="invalid-feedback">:message</div>'); ?>

</div>
<div class="form-group">
<label for="fecha_vencimiento" class="control-label"><?php echo e('Fecha Vencimiento'); ?></label>
<input type="text" class="form-control <?php echo e($errors->has('fecha_vencimiento')?'is-invalid':''); ?> " name="fecha_vencimiento" id="fecha_vencimiento" value="<?php echo e(isset($producto->fecha_vencimiento)?$producto->fecha_vencimiento:old('fecha_vencimiento')); ?>">
<?php echo $errors->first('fecha_vencimiento','<div class="invalid-feedback">:message</div>'); ?>

</div>

<input type="submit" class="btn btn-success" value="<?php echo e($Modo=='crear'? 'Agregar ':'Modificar'); ?>">
<a class="btn btn-primary" href="<?php echo e(url('productos')); ?>" >Regresar</a>
<?php /**PATH C:\xampp\htdocs\Laravel-Apps\Inventario\resources\views/productos/form.blade.php ENDPATH**/ ?>