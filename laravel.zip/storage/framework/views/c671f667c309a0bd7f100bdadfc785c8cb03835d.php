
<?php $__env->startSection('content'); ?>

<div class='container'>


<?php if(Session::has('Mensaje1')): ?>
<div class="alert alert-success" role="alert">
<?php echo e(Session::get('Mensaje1')); ?>

</div>

<?php endif; ?>




<a href="<?php echo e(url('clientes/create ')); ?>" class= "btn btn-success">Agregar Empleado</a>
<br/>
<br/>
<table class="table table-light table-hover">
    <thead class="thead-light">
        <tr>
            <th>ID</th>
            <th>Documento</th>
            <th>Nombre</th>
            <th>Id Compra</th>
            <th>Acciones</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
        <td><?php echo e($loop->iteration); ?></td>
        <td><?php echo e($cliente->documento); ?></td>
        <td><?php echo e($cliente->nombre); ?> <?php echo e($cliente->apellido); ?></td>
        <td><?php echo e($cliente->id_compra); ?></td>
        <td>
        <a class="btn btn-warning" href="<?php echo e(url('/clientes/'.$cliente->id.'/edit')); ?>">
        Editar
        </a>    
        <form method="post" action="<?php echo e(url('/clientes/'.$cliente->id)); ?>" style="display:inline">
        <?php echo e(csrf_field()); ?>

        <?php echo e(method_field('DELETE')); ?>

        <button class="btn btn-danger" type="submit" onclick="return confirm('¿BORRAR?')">Borrar</button>
        
        </form>
        </td>
        </form>
        </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
    </tbody>
</table>
<?php echo e($clientes->links()); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel-Apps\Inventario\resources\views/clientes/index.blade.php ENDPATH**/ ?>