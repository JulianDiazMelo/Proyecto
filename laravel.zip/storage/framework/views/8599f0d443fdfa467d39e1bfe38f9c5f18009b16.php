
<?php $__env->startSection('content'); ?>

<div class='container'>


<?php if(Session::has('Mensaje2')): ?>
<div class="alert alert-success" role="alert">
<?php echo e(Session::get('Mensaje2')); ?>

</div>
<?php endif; ?>




<a href="<?php echo e(url('compras/create ')); ?>" class= "btn btn-success">Agregar Compra</a>
<br/>
<br/>

<table class="table table-light table-hover">
    <thead class="thead-light">
        <tr>
            <th>ID</th>
            <th>ID Compra</th>
            <th>Producto</th>
            <th>Cantidad</th>
            <th>Acciones</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $compras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $compra): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
        <td><?php echo e($loop->iteration); ?></td>
        <td><?php echo e($compra->cod_compra); ?></td>
        <td><?php echo e($compra->producto); ?> </td>
        <td><?php echo e($compra->cantidad); ?></td>
        <td>
        <a class="btn btn-warning" href="<?php echo e(url('/compras/'.$compra->id.'/edit')); ?>">
        Editar
        </a>    
        <form method="post" action="<?php echo e(url('/compras/'.$compra->id)); ?>" style="display:inline">
        <?php echo e(csrf_field()); ?>

        <?php echo e(method_field('DELETE')); ?>

        <button class="btn btn-danger" type="submit" onclick="return confirm('¿BORRAR?')">Borrar</button>
        
        </form>
        </td>
        </form>
        </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
    </tbody>
</table>
<?php echo e($compras->links()); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel-Apps\Inventario\resources\views/compras/index.blade.php ENDPATH**/ ?>